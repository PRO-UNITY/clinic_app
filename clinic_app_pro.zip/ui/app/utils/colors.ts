export const mainColor = '#054A80';
export const yellowColor = '#FFC700';
export const blueColor = '#0B60B0';
export const greenColor = '#4cd137';
export const redColor = '#e84118';
export const grayColor = '#7f8fa6';
