import * as colors from './colors';
import * as showAsyncStorage from './showAsyncStorage';

export const BASE_URL = 'http://192.168.0.163:8000';
