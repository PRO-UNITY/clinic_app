export interface NotificationItemType {
  sender?: any;
  avatar?: string;
  isSeen?: boolean | string;
  date?: string;
  content?: string;
  notificationId?: number | any;
  navigation?: any;
}
