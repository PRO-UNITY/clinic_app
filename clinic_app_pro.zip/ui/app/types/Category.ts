export interface Category {
  id?: number;
  name?: string;
  logo?: string;
  screen?: string;
  categoryId?: any;
  navigation?: any;
}
