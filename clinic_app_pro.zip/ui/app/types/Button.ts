interface Button {
  onPress: () => void;
  label: string;
  color?: string;
}
