export interface BusyDay {
  timestamp: string;
}
