export { default as Doctors } from "./doctors/Doctors";
export { default as ViewDoctor } from "./doctors/ViewDoctor";
export { default as AddDoctors } from "./doctors/AddDoctors";
export { default as EditDoctors } from "./doctors/EditDoctors";
