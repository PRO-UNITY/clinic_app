import NoRole from './roles-route/NoRole';

const App = () => {
  return (
    <div>
      <NoRole />
    </div>
  );
};

export default App;
