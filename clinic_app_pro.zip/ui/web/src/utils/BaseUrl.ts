export const BASE_URL = "https://api.prounity.uz/clinic";
